#pragma once
#include <iostream>
#include "tinybmp.h"

class tinybmp_rotate : public tinybmp
{
public:
	tinybmp_rotate(std::string file_name)
		:tinybmp(file_name)
	{

	}


public:
	void rotate()
	{
		int temp = m_bih.height;
		m_bih.height = m_bih.width;
		m_bih.width = temp;

		unsigned char** new_image_buf = create_bitmap_24bit(m_bih.height, m_bih.width);
		for (int j = 0; j < m_bih.width; j++)
		{
			for (int i = 0; i < m_bih.height; i++)
			{
				new_image_buf[i][3*j] = m_image_buf[m_bih.width - j - 1][3*i];
				new_image_buf[i][3*j+1] = m_image_buf[m_bih.width - j - 1][3*i+1];
				new_image_buf[i][3*j+2] = m_image_buf[m_bih.width - j - 1][3*i+2];
			}
		}
	

		for (int i = 0; i < m_bih.width; i++)
		{
			delete[] m_image_buf[i];
		}

		delete[] m_image_buf;

		m_image_buf = new_image_buf;

	}
};