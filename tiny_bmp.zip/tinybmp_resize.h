#pragma once
#include <iostream>
#include "tinybmp.h"

class tinybmp_resize : public tinybmp
{
public:
	tinybmp_resize(std::string file_name)
		:tinybmp(file_name)
	{

	}


public:
	void resize_half()
	{
		m_bih.height /= 2;
		m_bih.width /= 2;
		unsigned char** new_image_buf = create_bitmap_24bit(m_bih.height, m_bih.width);
		for (int i = 0; i < m_bih.height*2; i++)
		{
			for (int j = 0; j < m_bih.width*3*2; j+=3)
			{
				if (i % 2 == 0 && j % 2 == 0)
				{
					new_image_buf[i / 2][j / 2] = m_image_buf[i][j];
					new_image_buf[i / 2][j / 2+1] = m_image_buf[i][j+1];
					new_image_buf[i / 2][j / 2+2] = m_image_buf[i][j+2];
				}
			}
		}

		for (int i = 0; i < m_bih.height*2; i++)
		{
			delete[] m_image_buf[i];
		}

		delete[] m_image_buf;

		m_image_buf = new_image_buf;

	}
	void resize_expand()
	{
		m_bih.height *= 2;
		m_bih.width *= 2;
		unsigned char** new_image_buf = create_bitmap_24bit(m_bih.height, m_bih.width);
		for (int i = 0; i < m_bih.height/2; i++)
		{
			for (int j = 0; j < m_bih.width/2*3; j+=3)
			{
				new_image_buf[2 * i][2 * j] = m_image_buf[i][j];
				new_image_buf[2 * i][2 * j + 3] = m_image_buf[i][j];
				new_image_buf[2 * i + 1][2 * j] = m_image_buf[i][j];
				new_image_buf[2 * i + 1][2 * j + 3] = m_image_buf[i][j];

				new_image_buf[2 * i][2 * j + 1] = m_image_buf[i][j+1];
				new_image_buf[2 * i][2 * j + 3 + 1] = m_image_buf[i][j+1];
				new_image_buf[2 * i + 1][2 * j + 1] = m_image_buf[i][j+1];
				new_image_buf[2 * i + 1][2 * j + 3 + 1] = m_image_buf[i][j+1];
 
				new_image_buf[2 * i][2 * j + 2] = m_image_buf[i][j+2];
				new_image_buf[2 * i][2 * j + 3 + 2] = m_image_buf[i][j+2];
				new_image_buf[2 * i + 1][2 * j + 2] = m_image_buf[i][j+2];
				new_image_buf[2 * i + 1][2 * j + 3 + 2] = m_image_buf[i][j+2];

			}
		}

		for (int i = 0; i < m_bih.height/2; i++)
		{
			delete[] m_image_buf[i];
		}

		delete[] m_image_buf;

		m_image_buf = new_image_buf;

	}
};