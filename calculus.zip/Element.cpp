#include <stdio.h>
#include "Element.h"
#include <string>

Element::Element()
{
	m_raw_data = "";
	m_type = OP;
}

Element::Element(char* data)
{
	m_raw_data = data;
}


void Element::print(std::ostream& out)
{
	out << m_raw_data;
}

void Element::set_raw_data(std::string data)
{
	m_raw_data = data;
}

std::string Element::get_raw_data()
{
	return m_raw_data;
}

Element::TYPE Element::get_type()
{
	return m_type;
}

Element::TYPE Element::resolve_type(Element* elem1, Element* elem2)
{
	if (elem1->get_type() == Element::FLOAT && elem2->get_type() == Element::INT)
		return Element::FLOAT;
	
	else if (elem1->get_type() == Element::INT && elem2->get_type() == Element::FLOAT)
		return Element::FLOAT;
	
	else if (elem1->get_type() == Element::INT && elem2->get_type() == Element::INT)
		return Element::INT;
	
	else
		return Element::FLOAT;
}