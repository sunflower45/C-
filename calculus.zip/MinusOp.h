#pragma once

#ifndef __MINUSOP__H
#define __MINUSOP__H

#include "OperationElement.h"
#include "NumberElement.h"

class NumberElement;

class MinusOp : public OperationElement
{
public:
	MinusOp();
	MinusOp(char* data);

public:
	NumberElement* Evaluate(NumberElement* elem1, NumberElement* elem2);
	int get_precedence();
};
#endif