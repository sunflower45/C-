#include <iostream>
#include "OperationElement.h"
#include "PlusOp.h"
#include "MinusOp.h"
#include "ModulerOp.h"
#include "MultiplyOp.h"
#include "DivisionOp.h"

OperationElement::OperationElement()
	:Element()
{
	
}

OperationElement::OperationElement(char* data)
	:Element(data)
{
	
}


bool OperationElement::operator<(OperationElement& rhs)
{
	if (rhs.get_raw_data() == "+")
	{
		OperationElement *op = new PlusOp();
		if (rhs.get_precedence()>op->get_precedence())
			return true;
		else
			return false;
	}
	else if (rhs.get_raw_data() == "-")
	{
		OperationElement *op = new MinusOp();
		if (rhs.get_precedence()>op->get_precedence())
			return true;
		else
			return false;
	}
	else if (rhs.get_raw_data() == "*")
	{
		OperationElement *op = new MultiplyOp();
		if (rhs.get_precedence()>op->get_precedence())
			return true;
		else
			return false;
	}
	else if (rhs.get_raw_data() == "/")
	{
		OperationElement *op = new DivisionOp();
		if (rhs.get_precedence()>op->get_precedence())
			return true;
		else
			return false;
	}
	else
	{
		OperationElement *op = new ModulerOp();
		if (rhs.get_precedence()>op->get_precedence())
			return true;
		else
			return false;
	}
}