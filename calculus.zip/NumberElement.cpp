#include <iostream>
#include "NumberElement.h"

NumberElement::NumberElement()
	:Element()
{
	
}
NumberElement::NumberElement(char* data)
	:Element(data)
{
	
}

NumberElement::NumberElement(int val)
	: Element()
{
	set_raw_data(std::to_string(val));
	m_type = INT;
}

NumberElement::NumberElement(float val)
	:Element()
{
	set_raw_data(std::to_string(val));
	m_type = FLOAT;
}

NumberElement::NumType NumberElement::get_val()
{
	return m_value;
}