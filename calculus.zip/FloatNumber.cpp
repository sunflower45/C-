#include <iostream>
#include "FloatNumber.h"

FloatNumber::FloatNumber()
	:NumberElement()
{

}

FloatNumber::FloatNumber(char* data)
	:NumberElement(data)
{
	
}

FloatNumber::FloatNumber(float val)
	:NumberElement(val)
{
	m_value.floating_point = val;
	m_value.integer = 0;
}


void FloatNumber::set_val(float val)
{
	m_value.floating_point = val;
	m_value.integer = 0;
}