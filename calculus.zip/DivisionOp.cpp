#include <iostream>
#include "DivisionOp.h"
#include "FloatNumber.h"
#include "IntegerNumber.h"

DivisionOp::DivisionOp()
{
	m_type = OP;
	set_raw_data("/");
}

DivisionOp::DivisionOp(char* data)
{
	m_type = OP;
	set_raw_data("/");
}

NumberElement* DivisionOp::Evaluate(NumberElement* elem1, NumberElement* elem2)
{
	if (resolve_type(elem1, elem2) == Element::FLOAT)
	{
		float f_elem1 = std::stof(elem1->get_raw_data());
		float f_elem2 = std::stoi(elem2->get_raw_data());
		NumberElement* result = new FloatNumber(f_elem1 / f_elem2);
		return result;
	}
	else
	{
		int f_elem1 = std::stoi(elem1->get_raw_data());
		int f_elem2 = std::stoi(elem2->get_raw_data());
		NumberElement* result = new IntegerNumber(f_elem1 / f_elem2);
		return result;
	}
}

int DivisionOp::get_precedence()
{
	return 1;
}
