#include <iostream>
#include "IntegerNumber.h"

IntegerNumber::IntegerNumber()
	:NumberElement()
{
	
}

IntegerNumber::IntegerNumber(char* data)
	:NumberElement(data)
{
	
}

IntegerNumber::IntegerNumber(int val)
	:NumberElement(val)
{
	m_value.integer = val;
	m_value.floating_point = 0.0;
}

void IntegerNumber::set_val(int val)
{
	m_value.integer = val;
	m_value.floating_point = 0.0;
}