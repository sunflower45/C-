#pragma once

#ifndef __DIVISIONOP__H
#define __DIVISIONOP__H

#include "OperationElement.h"
#include "NumberElement.h"

class NumberElement;

class DivisionOp : public OperationElement
{
public:
	DivisionOp();
	DivisionOp(char* data);

public:
	NumberElement* Evaluate(NumberElement* elem1, NumberElement* elem2);
	int get_precedence();
};
#endif
