#pragma once

#ifndef __ELEMENT__H
#define __ELEMENT__H
#include <string>
#include <iostream>

class Element
{
public:
	// enum TYPE {INT, FLOAT, RAD, VAR, OP};
	// You don't have to think about RAD, VAR
	enum TYPE {INT, FLOAT, OP};

public: 
	Element();
	Element(char* data);

public:
	void print(std::ostream& out);

	void set_raw_data(std::string data);

	// You must implement get_raw_data function. [Mandatory]
	// It returns string value of the expression.
	std::string get_raw_data();

	// You must implement the get_type function. [Mandatory]
	TYPE get_type();

protected:
	std::string m_raw_data;
	TYPE m_type;

protected:
	// The resolve_type function resolve the types. 
	// For example, 
	// if elem1 is INT type and elem2 is INT type then it returns INT
	// if elem1 or elem2 is FLOAT type then it returns FLOAT
	TYPE resolve_type(Element* elem1, Element* elem2);
};

#endif