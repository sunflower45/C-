#include <iostream>
#include <string>
#include <vector>
#include "FloatNumber.h"
#include "IntegerNumber.h"
#include "MultiplyOp.h"
#include "PlusOp.h"
#include "SciCal.h"
#include "MinusOp.h"
#include "DivisionOp.h"
#include "ModulerOp.h"

SciCal::SciCal(std::string expression)
{
	/*m_expressionList = expression;
	ParseExpression(m_expressionList);
	EvaluateExpression()->print(std::cout);
	std::cout << std::endl;*/
	
}


void SciCal::ParseExpression(std::string expr) //����
{
	std::vector<char> number;
	for (int i = 0; i < expr.length(); i++)
	{
		switch (expr[i]) 
		{
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
		case '.':
		{
			//���� stirng ��ü�� number�� �����Ѵ�.
			number.push_back(expr[i]);
		}
		break;
		case '+':
		{
			if (number.empty()==false)
			{
				std::string number_str(number.begin(), number.end());
				PushNumber(number_str); //pushnumber�� string���ε� ���ڸ� ���� �ִ´�.
				number.clear();
			}

			m_ElementList.push_back(new PlusOp); //���� �����ڸ� element list�� push

		}
		break;

		case '*':
		{
			if (number.empty() == false)
			{
				std::string number_str(number.begin(), number.end());
				PushNumber(number_str); //pushnumber�� string���ε� ���ڸ� ���� �ִ´�.
				number.clear();
			}
			m_ElementList.push_back(new MultiplyOp); //���� �����ڸ� element list�� push
		}
		break;

		case '-':
		{			
			if (number.empty() == false)
			{
				std::string number_str(number.begin(), number.end());
				PushNumber(number_str);
				number.clear();
			}
			m_ElementList.push_back(new MinusOp);
		}
		break;

		case '/':
		{
			if (number.empty() == false)
			{
				std::string number_str(number.begin(), number.end());
				PushNumber(number_str);
				number.clear();
			}
			m_ElementList.push_back(new DivisionOp);
		}
		break;

		case '%':
		{
			if (number.empty() == false)
			{
				std::string number_str(number.begin(), number.end());
				PushNumber(number_str);
				number.clear();
			}
			m_ElementList.push_back(new ModulerOp);
		}
		break;

		case '(':
		{
			Element* open_par = new Element;
			open_par->set_raw_data("(");
			m_ElementList.push_back(open_par);
		}
		break;

		case ')':
		{
			std::string number_str(number.begin(), number.end());
			PushNumber(number_str);
			number.clear();
			Element* close_par = new Element;
			close_par->set_raw_data(")");
			m_ElementList.push_back(close_par);
		}
		break;

		case '=':
		{
			if (number.empty() == false)
			{
				std::string number_str(number.begin(), number.end());
				PushNumber(number_str);
				number.clear();
			}

		}
		break;
		default:
			break;
		}
	}
}



void SciCal::PushNumber(std::string number)
{
	if (number.find(".") != std::string::npos)
	{
		m_ElementList.push_back(new FloatNumber(atof(number.c_str())));
	}
	else
	{
		m_ElementList.push_back(new IntegerNumber(atoi(number.c_str())));
	}

}
void SciCal::PrintElements()
{
	for (int i = 0; i < m_ElementList.size(); i++)
	{
		std::cout << m_ElementList[i] << " ";
	}
	std::cout<<std::endl;
}
void SciCal::PrintElements(std::vector<Element*>& list)
{
	for (int i = 0; i < list.size(); i++)
	{
		std::cout << list[i] << " ";
	}
	std::cout << std::endl;
}


std::vector<Element*> SciCal::TransformPostfix(std::vector<Element*> element_list)
{
	std::vector<OperationElement*> op_stack;
	std::vector<Element*> whole_stack;
	std::vector<OperationElement*> par_stack;
	bool is_paren = false;

	for (int i = 0; i < element_list.size(); i++)
	{
		if (is_paren == false)
		{
			if (element_list[i]->get_type() == Element::OP) //Ÿ���� op�̸�
			{
				if (op_stack.empty() == true)
				{
					if (element_list[i]->get_raw_data() == "+")
						op_stack.push_back(new PlusOp);
					else if (element_list[i]->get_raw_data() == "-")
						op_stack.push_back(new MinusOp);
					else if (element_list[i]->get_raw_data() == "*")
						op_stack.push_back(new MultiplyOp);
					else if (element_list[i]->get_raw_data() == "/")
						op_stack.push_back(new DivisionOp);
					else if (element_list[i]->get_raw_data() == "%")
						op_stack.push_back(new ModulerOp);
					else if (element_list[i]->get_raw_data() == "(")
					{
						is_paren = true;
					}
				}

				else
				{
					OperationElement* op;
					if (element_list[i]->get_raw_data() == "+")
						op = new PlusOp;
					else if (element_list[i]->get_raw_data() == "-")
						op = new MinusOp;
					else if (element_list[i]->get_raw_data() == "*")
						op = new MultiplyOp;
					else if (element_list[i]->get_raw_data() == "/")
						op = new DivisionOp;
					else if (element_list[i]->get_raw_data() == "%")
						op = new ModulerOp;
					else if (element_list[i]->get_raw_data() == "(")
					{
						is_paren = true;
						continue;
					}
					else if (element_list[i]->get_raw_data() == ")")
						is_paren = false;


					if (op_stack.back()->get_precedence() >= op->get_precedence()) //�ؿ��ִ°� �켱���� �� ������
					{
						while (op_stack.back()->get_precedence() >= op->get_precedence())
						{
							whole_stack.push_back(op_stack.back());
							op_stack.pop_back();

							if (op_stack.empty() == true)
								break;
						}
						op_stack.push_back(op);
					}
					else
					{
						//���߿� ���°� �켱���� �� ������ �׳� ���ÿ� �ֱ⸸ �Ѵ�
						op_stack.push_back(op);
					}
				}
			}

			else //�����̸�
			{
				whole_stack.push_back(element_list[i]);
			}

		}


		else //parenthesis������ �� 
		{
			if (element_list[i]->get_type() == Element::OP) //Ÿ���� op�̸�
			{
				if (par_stack.empty() == true)
				{
					if (element_list[i]->get_raw_data() == "+")
						par_stack.push_back(new PlusOp);

					else if (element_list[i]->get_raw_data() == "-")
						par_stack.push_back(new MinusOp);

					else if (element_list[i]->get_raw_data() == "*")
						par_stack.push_back(new MultiplyOp);

					else if (element_list[i]->get_raw_data() == "/")
						par_stack.push_back(new DivisionOp);
					else if (element_list[i]->get_raw_data() == "%")
						par_stack.push_back(new ModulerOp);

				}

				else
				{
					OperationElement* op;
					if (element_list[i]->get_raw_data() == "+")
						op = new PlusOp;
					else if (element_list[i]->get_raw_data() == "-")
						op = new MinusOp;
					else if (element_list[i]->get_raw_data() == "*")
						op = new MultiplyOp;
					else if (element_list[i]->get_raw_data() == "/")
						op = new DivisionOp;
					else if (element_list[i]->get_raw_data() == "%")
						op = new ModulerOp;
					else if (element_list[i]->get_raw_data() == ")")
					{
						while(par_stack.empty()!=true)
						{
							whole_stack.push_back(par_stack.back());
							par_stack.pop_back(); //�����ִ� op_stack�� ��� op���� whole stack�� �ֱ�
						}
						is_paren = false;
						continue;
					}

					if (par_stack.back()->get_precedence() >= op->get_precedence()) //�ؿ��ִ°� �켱���� �� ������
					{
						while (par_stack.back()->get_precedence() >= op->get_precedence())
						{
							whole_stack.push_back(par_stack.back());
							par_stack.pop_back();

							if (par_stack.empty() == true)
								break;
						}
						par_stack.push_back(op);
					}
					else
					{//���߿� ���°� �켱���� �� ������ �׳� ���ÿ� �ֱ⸸ �Ѵ�
						par_stack.push_back(op);
					}
				}
			}

			else //�����̸�
			{
				whole_stack.push_back(element_list[i]);
			}

		}
	}

	while(op_stack.empty()!=true)
	{
		whole_stack.push_back(op_stack.back());
		op_stack.pop_back(); //�����ִ� op_stack�� ��� op���� whole stack�� �ֱ�
	}

	return whole_stack;
	
}
/*
1. SciCal constructor
2. Parse Expression (inside of constructor)
3. Evaluate Expression
*/
NumberElement* SciCal::EvaluateExpression()
{
	std::vector<Element*> post_vec = TransformPostfix(m_ElementList);
	std::vector<NumberElement*> eval;

	for (int i = 0; i < post_vec.size(); i++)
	{
		if (post_vec[i]->get_type() != Element::OP)
		{

			if (post_vec[i]->get_type() == Element::INT)
			{
				eval.push_back(new IntegerNumber(std::stoi(post_vec[i]->get_raw_data())));
			}
			else if (post_vec[i]->get_type() == Element::FLOAT)
			{
				eval.push_back(new FloatNumber(std::stof(post_vec[i]->get_raw_data())));
			}
		}
		else //op��
		{
			NumberElement* elem1= new NumberElement;
			NumberElement* elem2 = new NumberElement;

			elem1 = eval.back();
			eval.pop_back();
			elem2 = eval.back();
			eval.pop_back();
			

			OperationElement* eval_with_op;
			if (post_vec[i]->get_raw_data() == "+")
			{
				eval_with_op = new PlusOp;
				eval.push_back(eval_with_op->Evaluate(elem2, elem1));
			}
			else if (post_vec[i]->get_raw_data() == "-")
			{
				eval_with_op = new MinusOp;
				eval.push_back(eval_with_op->Evaluate(elem2, elem1));
			}
			else if (post_vec[i]->get_raw_data() == "*")
			{
				eval_with_op = new MultiplyOp;
				eval.push_back(eval_with_op->Evaluate(elem2, elem1));
			}
			else if (post_vec[i]->get_raw_data() == "/")
			{
				eval_with_op = new DivisionOp;
				eval.push_back(eval_with_op->Evaluate(elem2, elem1));
			}
			else if (post_vec[i]->get_raw_data() == "%")
			{
				eval_with_op = new ModulerOp;
				eval.push_back(eval_with_op->Evaluate(elem2, elem1));
			}

		}
	}

	return eval.back();
}
