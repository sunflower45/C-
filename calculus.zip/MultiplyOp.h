#pragma once

#ifndef __MULTIPLYOP__H
#define __MULTIPLYOP__H

#include "OperationElement.h"
#include "NumberElement.h"

class NumberElement;

class MultiplyOp : public OperationElement
{
public:
	MultiplyOp();
	MultiplyOp(char* data);

public:
	NumberElement* Evaluate(NumberElement* elem1, NumberElement* elem2);
	int get_precedence();
};
#endif