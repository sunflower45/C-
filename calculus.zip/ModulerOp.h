#pragma once

#ifndef __MODULEROP__H
#define __MODULEROP__H

#include "OperationElement.h"
#include "NumberElement.h"

class NumberElement;

class ModulerOp : public OperationElement
{
public:
	ModulerOp();
	ModulerOp(char* data);

public:
	NumberElement* Evaluate(NumberElement* elem1, NumberElement* elem2);
	int get_precedence();
};
#endif
