#pragma once

#ifndef __CALCULATOR__H
#define __CALCULATOR__H

#include <string>
#include <vector>
#include "Element.h"


class NumberElement;

class SciCal
{
public:
	SciCal(std::string expression);

public:
	// You don't have to implement the void ParseExpression(unsigned int idx) function
	// void ParseExpression(unsigned int idx);

	// You should implement the  ParseExpression function. [Mandatory]
	void ParseExpression(std::string expr);

	// You may use PushNumber function. [Not Mandatory]
	void PushNumber(std::string number);

	// This function prints each element in m_ElementList [Mandatory]
	void PrintElements();
	// This function prints the elements from the given list [Mandatory]
	void PrintElements(std::vector<Element*>& list);

	// This function prints the elements from the given list [Mandatory]
	std::vector<Element*> TransformPostfix(std::vector<Element*> element_list);

	// This function prints the elements from the given list [Mandatory]
	NumberElement* EvaluateExpression();

protected:
	// You don't have to store the expression in the m_expressionList
	// std::vector<std::string> m_expressionList;

	// m_expressionList stores the given string expression using m_expressionList variable.
	// You must use it. [Mandatory]
	std::string m_expressionList;
	// m_ElementList stores elements of the expression.
	// You must use it. [Mandatory]
	std::vector<Element*> m_ElementList;
};

#endif
