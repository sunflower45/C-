#pragma once
#ifndef __INTEGER_NUMBER_H
#define __INTEGER_NUMBER_H

#include "NumberElement.h"
class IntegerNumber : public NumberElement
{
public:
	IntegerNumber();
	IntegerNumber(char* data);
	IntegerNumber(int val);

public:
	void set_val(int val);
};
#endif