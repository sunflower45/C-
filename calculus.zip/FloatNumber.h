#pragma once
#ifndef __FLOAT_NUMBER_H
#define __FLOAT_NUMBER_H

#include "NumberElement.h"
class FloatNumber : public NumberElement
{
public:
	FloatNumber();
	FloatNumber(char* data);
	FloatNumber(float val);

public:
	void set_val(float val);
};
#endif