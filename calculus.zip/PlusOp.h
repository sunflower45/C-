#pragma once

#ifndef __PLUSOP__H
#define __PLUSOP__H

#include "OperationElement.h"
#include "NumberElement.h"

class NumberElement;

class PlusOp : public OperationElement
{
public:
	PlusOp();
	PlusOp(char* data);

public:
	NumberElement* Evaluate(NumberElement* elem1, NumberElement* elem2);
	int get_precedence();
};
#endif