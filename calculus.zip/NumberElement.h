#pragma once

#ifndef __NUMBER_ELEMENT_H
#define __NUMBER_ELEMENT_H

#include "Element.h"

class NumberElement : public Element
{
public:
	NumberElement();
	NumberElement(char* data);
	NumberElement(int val);
	NumberElement(float val);

public:
	union NumType{int integer; float floating_point;};

	NumType get_val();

protected:
	// You should use m_value to store the numeric values.
	NumType m_value;
};
#endif