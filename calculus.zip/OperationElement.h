#pragma once

#ifndef __OPERATION_ELEMENT_H
#define __OPERATION_ELEMENT_H
#include "Element.h"

class NumberElement;

class OperationElement : public Element
{
public:
	OperationElement();
	OperationElement(char* data);

public:
	// You must implement the Evaluate function to evaluate the value of the expression. 
	// Inside of Evaluate you should use new operator to create IntegerElement or FloatElement to store the evaluation result.
	// Also, you must return it. [Mandatory]
	virtual NumberElement* Evaluate(NumberElement* elem1, NumberElement* elem2) = 0;
	
	// You must implement the get_precedence function to resolve the precedence between operators.  [Mandatory]
	virtual int get_precedence() = 0;

public:
	bool operator<(OperationElement& rhs);
};
#endif